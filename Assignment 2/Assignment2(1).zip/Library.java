/*
 * Name: ???
 * Student number: ???
 */

/*
 * A class to represent a library.
 * A library can either have unlimited book capacity or limited book capacity.
 * For limited capacity libraries, books on loan still count towards the 
 * capacity (there must be space reserved for when a book is returned).
 */
public class Library {
    // Define fields here
	// to be completed
    
    /*
     * Construct a Library with unlimited capacity.
     */ 
    public Library() {
		// to be completed
    }

    /*
     * Construct a Library with limited capacity.
     */ 
    public Library( int inCapacity ) {
		// to be completed
    }
    
    // Add methods here
    // to be completed
}


